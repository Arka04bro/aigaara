import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Programs from './components/Programs';
import Trainers from './components/Trainers';
import Merch from './components/Merch';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import UserProfile from './components/UserProfile';
import Schedule from './components/Schedule';
import BookingModal from './components/BookingModal';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedTraining, setSelectedTraining] = useState(null);
  const [currentView, setCurrentView] = useState('home');

  const handleLogin = (userData) => {
    setUser(userData);
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('home');
  };

  const handleProfileClick = () => {
    setCurrentView('profile');
  };

  const handleScheduleClick = () => {
    setCurrentView('schedule');
  };

  const handleLogoClick = () => {
    setCurrentView('home');
  };

  const handleBookTraining = (training) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    setSelectedTraining(training);
    setIsBookingModalOpen(true);
  };

  const handleConfirmBooking = (training) => {
    // Update user's bookings or training data
    console.log('Booking confirmed for:', training);
    setIsBookingModalOpen(false);
    setSelectedTraining(null);
  };

  if (currentView === 'profile' && user) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header 
          user={user} 
          onLoginClick={() => setIsAuthModalOpen(true)}
          onProfileClick={handleProfileClick}
          onScheduleClick={handleScheduleClick}
          onLogoClick={handleLogoClick}
          onLogout={handleLogout}
        />
        <UserProfile user={user} onLogout={handleLogout} />
        <AuthModal 
          isOpen={isAuthModalOpen} 
          onClose={() => setIsAuthModalOpen(false)}
          onLogin={handleLogin}
        />
      </div>
    );
  }

  if (currentView === 'schedule') {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header 
          user={user} 
          onLoginClick={() => setIsAuthModalOpen(true)}
          onProfileClick={handleProfileClick}
          onScheduleClick={handleScheduleClick}
          onLogoClick={handleLogoClick}
          onLogout={handleLogout}
        />
        <Schedule user={user} onBookTraining={handleBookTraining} />
        <AuthModal 
          isOpen={isAuthModalOpen} 
          onClose={() => setIsAuthModalOpen(false)}
          onLogin={handleLogin}
        />
        <BookingModal
          isOpen={isBookingModalOpen}
          onClose={() => setIsBookingModalOpen(false)}
          training={selectedTraining}
          user={user}
          onConfirmBooking={handleConfirmBooking}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header 
        user={user} 
        onLoginClick={() => setIsAuthModalOpen(true)}
        onProfileClick={handleProfileClick}
        onScheduleClick={handleScheduleClick}
        onLogoClick={handleLogoClick}
        onLogout={handleLogout}
      />
      <main>
        <Hero />
        <Programs />
        <Trainers />
        <Merch />
      </main>
      <Footer />
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
      />
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        training={selectedTraining}
        user={user}
        onConfirmBooking={handleConfirmBooking}
      />
    </div>
  );
}

export default App;
