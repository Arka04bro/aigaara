import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  CreditCard,
  CheckCircle,
  AlertCircle,
  User
} from 'lucide-react';

const BookingModal = ({ isOpen, onClose, training, user, onConfirmBooking }) => {
  const [step, setStep] = useState(1); // 1: details, 2: payment, 3: confirmation
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen || !training) return null;

  const handleBooking = async () => {
    setIsProcessing(true);
    
    // Simulate booking process
    setTimeout(() => {
      setStep(3);
      setIsProcessing(false);
      if (onConfirmBooking) {
        onConfirmBooking(training);
      }
    }, 2000);
  };

  const handleClose = () => {
    setStep(1);
    setPaymentMethod('card');
    setIsProcessing(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="aiga-card w-full max-w-lg relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-8">
          {/* Step 1: Training Details */}
          {step === 1 && (
            <>
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-foreground mb-2">Бронирование тренировки</h2>
                <p className="text-muted-foreground">Подтвердите детали вашей записи</p>
              </div>

              {/* Training Info */}
              <div className="bg-secondary rounded-lg p-6 mb-6">
                <h3 className="text-xl font-bold text-foreground mb-4">{training.title}</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center text-muted-foreground">
                    <User className="w-4 h-4 mr-3" />
                    <span>{training.trainer}</span>
                  </div>
                  
                  <div className="flex items-center text-muted-foreground">
                    <Calendar className="w-4 h-4 mr-3" />
                    <span>{new Date(training.date).toLocaleDateString('ru-RU', { 
                      weekday: 'long', 
                      day: 'numeric', 
                      month: 'long' 
                    })}</span>
                  </div>
                  
                  <div className="flex items-center text-muted-foreground">
                    <Clock className="w-4 h-4 mr-3" />
                    <span>{training.time} ({training.duration} мин)</span>
                  </div>
                  
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-3" />
                    <span>{training.location}</span>
                  </div>
                  
                  <div className="flex items-center text-muted-foreground">
                    <Users className="w-4 h-4 mr-3" />
                    <span>{training.currentParticipants + 1}/{training.maxParticipants} участников</span>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                  <span className="text-lg font-medium text-foreground">Стоимость:</span>
                  <span className="text-2xl font-bold text-primary">{training.price.toLocaleString()} ₸</span>
                </div>
              </div>

              {/* User Info */}
              <div className="bg-secondary rounded-lg p-4 mb-6">
                <h4 className="font-medium text-foreground mb-2">Участник</h4>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-medium text-foreground">{user?.name}</div>
                    <div className="text-sm text-muted-foreground">{user?.belt}</div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={handleClose} className="flex-1">
                  Отмена
                </Button>
                <Button 
                  onClick={() => setStep(2)} 
                  className="flex-1 aiga-gradient text-white hover:opacity-90"
                >
                  Продолжить
                </Button>
              </div>
            </>
          )}

          {/* Step 2: Payment */}
          {step === 2 && (
            <>
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-foreground mb-2">Оплата</h2>
                <p className="text-muted-foreground">Выберите способ оплаты</p>
              </div>

              {/* Payment Summary */}
              <div className="bg-secondary rounded-lg p-4 mb-6">
                <div className="flex justify-between items-center">
                  <span className="text-foreground">{training.title}</span>
                  <span className="font-bold text-primary">{training.price.toLocaleString()} ₸</span>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-3 mb-6">
                <div 
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    paymentMethod === 'card' 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => setPaymentMethod('card')}
                >
                  <div className="flex items-center">
                    <CreditCard className="w-5 h-5 mr-3 text-primary" />
                    <div>
                      <div className="font-medium text-foreground">Банковская карта</div>
                      <div className="text-sm text-muted-foreground">Visa, MasterCard, Мир</div>
                    </div>
                  </div>
                </div>

                <div 
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    paymentMethod === 'kaspi' 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => setPaymentMethod('kaspi')}
                >
                  <div className="flex items-center">
                    <div className="w-5 h-5 mr-3 bg-red-500 rounded text-white text-xs flex items-center justify-center font-bold">K</div>
                    <div>
                      <div className="font-medium text-foreground">Kaspi Pay</div>
                      <div className="text-sm text-muted-foreground">Быстрая оплата через Kaspi</div>
                    </div>
                  </div>
                </div>

                <div 
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    paymentMethod === 'subscription' 
                      ? 'border-primary bg-primary/5' 
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => setPaymentMethod('subscription')}
                >
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 mr-3 text-green-500" />
                    <div>
                      <div className="font-medium text-foreground">Абонемент</div>
                      <div className="text-sm text-muted-foreground">Списать с баланса абонемента</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                  Назад
                </Button>
                <Button 
                  onClick={handleBooking}
                  disabled={isProcessing}
                  className="flex-1 aiga-gradient text-white hover:opacity-90"
                >
                  {isProcessing ? 'Обработка...' : 'Оплатить'}
                </Button>
              </div>
            </>
          )}

          {/* Step 3: Confirmation */}
          {step === 3 && (
            <>
              <div className="text-center mb-6">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-foreground mb-2">Успешно забронировано!</h2>
                <p className="text-muted-foreground">Ваша тренировка успешно забронирована</p>
              </div>

              {/* Booking Details */}
              <div className="bg-secondary rounded-lg p-6 mb-6">
                <h3 className="font-bold text-foreground mb-4">Детали бронирования</h3>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Тренировка:</span>
                    <span className="text-foreground">{training.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Тренер:</span>
                    <span className="text-foreground">{training.trainer}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Дата:</span>
                    <span className="text-foreground">
                      {new Date(training.date).toLocaleDateString('ru-RU', { 
                        day: 'numeric', 
                        month: 'long' 
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Время:</span>
                    <span className="text-foreground">{training.time}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Место:</span>
                    <span className="text-foreground">{training.location}</span>
                  </div>
                </div>
              </div>

              {/* Important Info */}
              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-6">
                <div className="flex items-start">
                  <AlertCircle className="w-5 h-5 text-yellow-500 mr-3 mt-0.5" />
                  <div className="text-sm">
                    <div className="font-medium text-foreground mb-1">Важная информация</div>
                    <div className="text-muted-foreground">
                      Приходите за 15 минут до начала тренировки. При отмене менее чем за 2 часа деньги не возвращаются.
                    </div>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleClose}
                className="w-full aiga-gradient text-white hover:opacity-90"
              >
                Отлично!
              </Button>
            </>
          )}
        </div>
      </Card>
    </div>
  );
};

export default BookingModal;

