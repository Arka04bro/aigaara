import React from 'react';
import { Button } from './ui/button';
import { MapPin, Phone, Mail, Instagram, Facebook, Youtube } from 'lucide-react';
import logo from '../assets/logo.png';

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <img src={logo} alt="AIGA" className="h-12 w-auto" />
              <div>
                <h3 className="text-xl font-bold text-foreground">AIGA Connect</h3>
                <p className="text-sm text-muted-foreground">Sports League</p>
              </div>
            </div>
            <p className="text-muted-foreground mb-6 leading-relaxed max-w-md">
              Казахстанская федерация бразильского джиу-джитсу и грэпплинга. 
              Популяризация грэпплинга AIGA, развитие массового спорта и здорового образа жизни.
            </p>
            <div className="flex space-x-4">
              <Button size="sm" variant="outline" className="w-10 h-10 p-0">
                <Instagram className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline" className="w-10 h-10 p-0">
                <Facebook className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline" className="w-10 h-10 p-0">
                <Youtube className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-foreground mb-6">Быстрые ссылки</h4>
            <ul className="space-y-3">
              <li><a href="#programs" className="text-muted-foreground hover:text-primary transition-colors">Программы</a></li>
              <li><a href="#trainers" className="text-muted-foreground hover:text-primary transition-colors">Тренеры</a></li>
              <li><a href="#schedule" className="text-muted-foreground hover:text-primary transition-colors">Расписание</a></li>
              <li><a href="#pricing" className="text-muted-foreground hover:text-primary transition-colors">Цены</a></li>
              <li><a href="#merch" className="text-muted-foreground hover:text-primary transition-colors">Магазин</a></li>
              <li><a href="#contacts" className="text-muted-foreground hover:text-primary transition-colors">Контакты</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold text-foreground mb-6">Контакты</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="text-muted-foreground text-sm">г. Астана</p>
                  <p className="text-muted-foreground text-sm">ул. Ахмедьярова, 3</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-primary" />
                <p className="text-muted-foreground text-sm">+7 (777) 123-45-67</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-primary" />
                <p className="text-muted-foreground text-sm">info@aiga.kz</p>
              </div>
            </div>
          </div>
        </div>

        {/* Championship Info */}
        <div className="border-t border-border mt-12 pt-8">
          <div className="text-center">
            <h4 className="text-2xl font-bold text-foreground mb-4">
              AIGA GRAPPLING WORLD CHAMPIONSHIP
            </h4>
            <p className="text-lg text-primary font-semibold mb-2">
              🗓️ Almaty. June 28–29 | 📍 Baluan Sholak Sports Palace
            </p>
            <p className="text-muted-foreground mb-4">
              It's not just a tournament. It's a global showdown that will echo through the halls of combat sports history.
            </p>
            <p className="text-xl font-bold text-primary">Призовой фонд — 1 миллион долларов</p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm">
            © 2025 AIGA Kazakhstan. Все права защищены.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">
              Политика конфиденциальности
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary text-sm transition-colors">
              Условия использования
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

