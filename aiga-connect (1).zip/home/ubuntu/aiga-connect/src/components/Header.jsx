import React, { useState } from 'react';
import { Button } from './ui/button';
import { Menu, X, User, Calendar, ChevronDown, Settings, LogOut } from 'lucide-react';
import logo from '../assets/logo.png';

const Header = ({ user, onLoginClick, onProfileClick, onScheduleClick, onLogoClick, onLogout }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const navItems = [
    { name: 'Программы', href: '#programs' },
    { name: 'Тренеры', href: '#trainers' },
    { name: 'Расписание', href: '#schedule', onClick: onScheduleClick },
    { name: 'Цены', href: '#pricing' },
    { name: 'Контакты', href: '#contacts' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={onLogoClick}>
            <img src={logo} alt="AIGA" className="h-10 w-auto" />
            <div className="hidden sm:block">
              <h1 className="text-xl font-bold text-foreground">AIGA Connect</h1>
              <p className="text-xs text-muted-foreground">Sports League</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                onClick={item.onClick ? (e) => { e.preventDefault(); item.onClick(); } : undefined}
                className="aiga-nav-link text-foreground hover:text-primary font-medium cursor-pointer"
              >
                {item.name}
              </a>
            ))}
          </nav>

          {/* Desktop Auth/User Section */}
          <div className="hidden lg:flex items-center space-x-4">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-3 p-2 rounded-lg hover:bg-secondary transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-4 h-4 text-primary" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-medium text-foreground">{user.name}</div>
                    <div className="text-xs text-muted-foreground">{user.belt}</div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 top-full mt-2 w-48 bg-card border border-border rounded-lg shadow-lg py-2">
                    <button
                      onClick={() => {
                        onProfileClick();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-foreground hover:bg-secondary flex items-center"
                    >
                      <User className="w-4 h-4 mr-2" />
                      Мой профиль
                    </button>
                    <button
                      onClick={() => setIsUserMenuOpen(false)}
                      className="w-full px-4 py-2 text-left text-sm text-foreground hover:bg-secondary flex items-center"
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      Настройки
                    </button>
                    <hr className="my-2 border-border" />
                    <button
                      onClick={() => {
                        onLogout();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-foreground hover:bg-secondary flex items-center"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Выйти
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                  onClick={onLoginClick}
                >
                  <User className="w-4 h-4 mr-2" />
                  Войти
                </Button>
                <Button size="sm" className="aiga-gradient text-white hover:opacity-90">
                  <Calendar className="w-4 h-4 mr-2" />
                  Пробное занятие
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-foreground hover:text-primary"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-border">
            <nav className="flex flex-col space-y-4 mt-4">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={item.onClick ? (e) => { e.preventDefault(); item.onClick(); setIsMenuOpen(false); } : () => setIsMenuOpen(false)}
                  className="aiga-nav-link text-foreground hover:text-primary font-medium py-2 cursor-pointer"
                >
                  {item.name}
                </a>
              ))}
              <div className="flex flex-col space-y-3 pt-4">
                {user ? (
                  <>
                    <div className="flex items-center space-x-3 p-3 bg-secondary rounded-lg">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">{user.name}</div>
                        <div className="text-sm text-muted-foreground">{user.belt}</div>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        onProfileClick();
                        setIsMenuOpen(false);
                      }}
                    >
                      <User className="w-4 h-4 mr-2" />
                      Мой профиль
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        onLogout();
                        setIsMenuOpen(false);
                      }}
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Выйти
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      variant="outline" 
                      className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                      onClick={() => {
                        onLoginClick();
                        setIsMenuOpen(false);
                      }}
                    >
                      <User className="w-4 h-4 mr-2" />
                      Войти
                    </Button>
                    <Button className="aiga-gradient text-white hover:opacity-90">
                      <Calendar className="w-4 h-4 mr-2" />
                      Пробное занятие
                    </Button>
                  </>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;

