import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Play, Calendar, TrendingUp, Users } from 'lucide-react';
import athlete1 from '../assets/athlete1.png';

const Hero = () => {
  return (
        <section className="aiga-hero-bg min-h-screen flex items-center pt-20">
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="relative z-10">
            <div className="mb-6">
              <span className="inline-block px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium mb-4">
                🇰🇿 Казахстанская федерация бразильского джиу-джитсу и грэпплинга
              </span>
              <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
                Трансформируй
                <br />
                <span className="text-primary">свои</span>
                <br />
                тренировки
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Профессиональная платформа для боевых искусств.
                <br />
                Записывайтесь на тренировки, отслеживайте прогресс и
                <br />
                достигайте новых высот вместе с AIGA Connect.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button size="lg" className="aiga-gradient text-white hover:opacity-90 px-8 py-4 text-lg">
                <Calendar className="w-5 h-5 mr-2" />
                Начать тренировки
              </Button>
              <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-4 text-lg">
                <Play className="w-5 h-5 mr-2" />
                Смотреть видео
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="aiga-stats-card p-6 text-center">
                <div className="text-3xl font-bold text-primary mb-2">499+</div>
                <div className="text-sm text-muted-foreground">Активных учеников</div>
              </Card>
              <Card className="aiga-stats-card p-6 text-center">
                <div className="text-3xl font-bold text-primary mb-2">15+</div>
                <div className="text-sm text-muted-foreground">Опытных тренеров</div>
              </Card>
            </div>
          </div>

          {/* Right Content - Progress Card */}
          <div className="relative z-10">
            <Card className="aiga-card p-8 max-w-md mx-auto">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-foreground mb-2">Ваш прогресс</h3>
                <p className="text-muted-foreground">Отслеживайте свои достижения</p>
              </div>

              {/* Progress Bar */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-muted-foreground">Тренировки в месяц</span>
                  <span className="text-sm font-medium text-primary">11/16</span>
                </div>
                <div className="w-full bg-secondary rounded-full h-2">
                  <div className="aiga-progress-bar h-2 rounded-full" style={{ width: '68.75%' }}></div>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">11</div>
                  <div className="text-xs text-muted-foreground">Пояс</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">167</div>
                  <div className="text-xs text-muted-foreground">Очки</div>
                </div>
              </div>

              {/* Achievement Badge */}
              <div className="bg-primary/10 rounded-lg p-4 text-center">
                <TrendingUp className="w-8 h-8 text-primary mx-auto mb-2" />
                <div className="text-sm font-medium text-foreground">Прогресс недели</div>
                <div className="text-xs text-muted-foreground">+15% к предыдущей неделе</div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

