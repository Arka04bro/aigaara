import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ShoppingCart, Star, Heart, Eye } from 'lucide-react';
import merch1 from '../assets/merch1.png';

const Merch = () => {
  const products = [
    {
      id: 1,
      name: 'Рашгард AIGA Pro',
      price: '18,000 ₸',
      originalPrice: '22,000 ₸',
      image: merch1,
      rating: 4.8,
      reviews: 24,
      colors: ['Синий', 'Красный', 'Черный'],
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      description: 'Профессиональный рашгард для тренировок и соревнований',
      features: ['Компрессионная ткань', 'Быстросохнущий', 'Антибактериальная обработка'],
      sale: true
    },
    {
      id: 2,
      name: 'Шорты AIGA Competition',
      price: '15,000 ₸',
      image: merch1,
      rating: 4.9,
      reviews: 18,
      colors: ['Черный', 'Красный'],
      sizes: ['S', 'M', 'L', 'XL'],
      description: 'Соревновательные шорты для грэпплинга',
      features: ['Эластичная ткань', 'Усиленные швы', 'Удобная посадка']
    },
    {
      id: 3,
      name: 'Кимоно AIGA Academy',
      price: '45,000 ₸',
      image: merch1,
      rating: 5.0,
      reviews: 12,
      colors: ['Белый', 'Синий'],
      sizes: ['A1', 'A2', 'A3', 'A4'],
      description: 'Традиционное кимоно для бразильского джиу-джитсу',
      features: ['100% хлопок', 'Предварительная усадка', 'Плотная ткань 450gsm']
    },
    {
      id: 4,
      name: 'Пояс AIGA Belt',
      price: '8,000 ₸',
      image: merch1,
      rating: 4.7,
      reviews: 31,
      colors: ['Белый', 'Синий', 'Фиолетовый', 'Коричневый', 'Черный'],
      sizes: ['A1', 'A2', 'A3', 'A4'],
      description: 'Официальный пояс AIGA для всех уровней',
      features: ['Плотная ткань', 'Вышивка логотипа', 'Стандарт IBJJF']
    }
  ];

  return (
    <section id="merch" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Магазин экипировки
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Официальная экипировка AIGA Academy. Качественная одежда и аксессуары 
            для тренировок и соревнований от ведущих производителей.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="aiga-card overflow-hidden group">
              {/* Product Image */}
              <div className="relative overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-64 object-cover object-center group-hover:scale-105 transition-transform duration-300"
                />
                
                {/* Sale Badge */}
                {product.sale && (
                  <div className="absolute top-3 left-3 bg-primary text-white px-2 py-1 rounded text-xs font-medium">
                    СКИДКА
                  </div>
                )}

                {/* Action Buttons */}
                <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button size="sm" variant="secondary" className="w-8 h-8 p-0">
                    <Heart className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="secondary" className="w-8 h-8 p-0">
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="p-6">
                {/* Product Info */}
                <div className="mb-4">
                  <h3 className="text-lg font-bold text-foreground mb-2">{product.name}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{product.description}</p>
                  
                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-sm font-medium text-foreground ml-1">{product.rating}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">({product.reviews} отзывов)</span>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-4">
                  <ul className="space-y-1">
                    {product.features.slice(0, 2).map((feature, index) => (
                      <li key={index} className="text-xs text-muted-foreground flex items-center">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Colors */}
                <div className="mb-4">
                  <div className="text-xs text-muted-foreground mb-2">Цвета:</div>
                  <div className="flex gap-1">
                    {product.colors.slice(0, 3).map((color, index) => (
                      <span key={index} className="text-xs bg-secondary px-2 py-1 rounded">
                        {color}
                      </span>
                    ))}
                    {product.colors.length > 3 && (
                      <span className="text-xs text-muted-foreground">+{product.colors.length - 3}</span>
                    )}
                  </div>
                </div>

                {/* Price */}
                <div className="mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold text-primary">{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-muted-foreground line-through">{product.originalPrice}</span>
                    )}
                  </div>
                </div>

                {/* Add to Cart Button */}
                <Button className="w-full aiga-gradient text-white hover:opacity-90">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  В корзину
                </Button>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
            Посмотреть весь каталог
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Merch;

