import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Clock, Users, Star, Calendar } from 'lucide-react';

const Programs = () => {
  const programs = [
    {
      id: 1,
      title: 'Бразильское джиу-джитсу',
      description: 'Изучите основы и продвинутые техники BJJ с опытными инструкторами',
      duration: '90 мин',
      level: 'Все уровни',
      participants: '8-12',
      price: '15,000 ₸',
      features: ['Техника захватов', 'Позиционная борьба', 'Самооборона', 'Физическая подготовка'],
      popular: true
    },
    {
      id: 2,
      title: 'Грэпплинг',
      description: 'Спортивная борьба без ударов, развитие силы и техники',
      duration: '75 мин',
      level: 'Начинающий',
      participants: '6-10',
      price: '12,000 ₸',
      features: ['Техника борьбы', 'Кондиционная подготовка', 'Соревновательная практика', 'Тактика']
    },
    {
      id: 3,
      title: 'Детские группы',
      description: 'Безопасные и веселые тренировки для детей от 6 до 14 лет',
      duration: '60 мин',
      level: 'Детский',
      participants: '8-15',
      price: '10,000 ₸',
      features: ['Игровая форма', 'Дисциплина', 'Координация', 'Социализация']
    },
    {
      id: 4,
      title: 'Индивидуальные тренировки',
      description: 'Персональные занятия с тренером для быстрого прогресса',
      duration: '60 мин',
      level: 'Любой',
      participants: '1-2',
      price: '25,000 ₸',
      features: ['Персональный подход', 'Гибкий график', 'Быстрый прогресс', 'Индивидуальная программа']
    }
  ];

  return (
    <section id="programs" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Программы тренировок
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Выберите программу, которая подходит именно вам. От начинающих до профессионалов - 
            у нас есть тренировки для всех уровней подготовки.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {programs.map((program) => (
            <Card key={program.id} className={`aiga-card p-6 relative ${program.popular ? 'ring-2 ring-primary' : ''}`}>
              {program.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="aiga-gradient px-4 py-1 rounded-full text-white text-sm font-medium">
                    Популярно
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-xl font-bold text-foreground mb-3">{program.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{program.description}</p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="w-4 h-4 mr-2 text-primary" />
                  {program.duration}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Users className="w-4 h-4 mr-2 text-primary" />
                  {program.participants} участников
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Star className="w-4 h-4 mr-2 text-primary" />
                  {program.level}
                </div>
              </div>

              <div className="mb-6">
                <div className="text-2xl font-bold text-primary mb-4">{program.price}</div>
                <ul className="space-y-2">
                  {program.features.map((feature, index) => (
                    <li key={index} className="text-sm text-muted-foreground flex items-center">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <Button 
                className={`w-full ${program.popular ? 'aiga-gradient text-white hover:opacity-90' : 'border-primary text-primary hover:bg-primary hover:text-primary-foreground'}`}
                variant={program.popular ? 'default' : 'outline'}
              >
                <Calendar className="w-4 h-4 mr-2" />
                Записаться
              </Button>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
            Посмотреть все программы
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Programs;

