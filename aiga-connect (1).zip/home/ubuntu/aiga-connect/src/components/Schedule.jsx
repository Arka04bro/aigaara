import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  ChevronLeft, 
  ChevronRight,
  Filter,
  Search,
  Plus
} from 'lucide-react';

const Schedule = ({ user, onBookTraining }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [viewMode, setViewMode] = useState('week'); // week, day

  // Mock data for training schedule
  const trainings = [
    {
      id: 1,
      title: 'Бразильское джиу-джитсу',
      trainer: 'Алибек Нурланов',
      time: '18:00',
      duration: 90,
      location: 'Зал 1',
      level: 'Все уровни',
      maxParticipants: 12,
      currentParticipants: 8,
      date: '2025-07-22',
      price: 3000,
      isBooked: false
    },
    {
      id: 2,
      title: 'Грэпплинг',
      trainer: 'Данияр Касымов',
      time: '19:30',
      duration: 75,
      location: 'Зал 2',
      level: 'Начинающий',
      maxParticipants: 10,
      currentParticipants: 6,
      date: '2025-07-22',
      price: 2500,
      isBooked: true
    },
    {
      id: 3,
      title: 'Детские группы',
      trainer: 'Айгерим Сейтова',
      time: '16:00',
      duration: 60,
      location: 'Зал 1',
      level: 'Детский',
      maxParticipants: 15,
      currentParticipants: 12,
      date: '2025-07-22',
      price: 2000,
      isBooked: false
    },
    {
      id: 4,
      title: 'Бразильское джиу-джитсу',
      trainer: 'Алибек Нурланов',
      time: '18:00',
      duration: 90,
      location: 'Зал 1',
      level: 'Все уровни',
      maxParticipants: 12,
      currentParticipants: 9,
      date: '2025-07-23',
      price: 3000,
      isBooked: false
    },
    {
      id: 5,
      title: 'Индивидуальная тренировка',
      trainer: 'Данияр Касымов',
      time: '20:00',
      duration: 60,
      location: 'Зал 2',
      level: 'Любой',
      maxParticipants: 2,
      currentParticipants: 0,
      date: '2025-07-23',
      price: 12500,
      isBooked: false
    }
  ];

  const weekDays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
  const months = [
    'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
  ];

  const getWeekDates = (date) => {
    const week = [];
    const startDate = new Date(date);
    const day = startDate.getDay();
    const diff = startDate.getDate() - day + (day === 0 ? -6 : 1);
    startDate.setDate(diff);

    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(startDate);
      currentDate.setDate(startDate.getDate() + i);
      week.push(currentDate);
    }
    return week;
  };

  const formatDate = (date) => {
    return date.toISOString().split('T')[0];
  };

  const getTrainingsForDate = (date) => {
    const dateStr = formatDate(date);
    return trainings.filter(training => training.date === dateStr);
  };

  const filteredTrainings = trainings.filter(training => {
    if (selectedFilter === 'all') return true;
    if (selectedFilter === 'available') return !training.isBooked;
    if (selectedFilter === 'booked') return training.isBooked;
    return true;
  });

  const handleBooking = (training) => {
    if (user && onBookTraining) {
      onBookTraining(training);
    }
  };

  const weekDates = getWeekDates(selectedDate);

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Расписание тренировок</h1>
            <p className="text-muted-foreground">Выберите удобное время для тренировок</p>
          </div>
          
          <div className="flex items-center gap-4 mt-4 lg:mt-0">
            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === 'week' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('week')}
              >
                Неделя
              </Button>
              <Button
                variant={viewMode === 'day' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('day')}
              >
                День
              </Button>
            </div>
            
            <select
              value={selectedFilter}
              onChange={(e) => setSelectedFilter(e.target.value)}
              className="px-3 py-2 bg-secondary border border-border rounded-md text-foreground"
            >
              <option value="all">Все тренировки</option>
              <option value="available">Доступные</option>
              <option value="booked">Забронированные</option>
            </select>
          </div>
        </div>

        {/* Calendar Navigation */}
        <Card className="aiga-card p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const newDate = new Date(selectedDate);
                  newDate.setDate(selectedDate.getDate() - 7);
                  setSelectedDate(newDate);
                }}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              
              <h2 className="text-xl font-bold text-foreground">
                {months[selectedDate.getMonth()]} {selectedDate.getFullYear()}
              </h2>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const newDate = new Date(selectedDate);
                  newDate.setDate(selectedDate.getDate() + 7);
                  setSelectedDate(newDate);
                }}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
            
            <Button
              variant="outline"
              onClick={() => setSelectedDate(new Date())}
            >
              Сегодня
            </Button>
          </div>

          {/* Week View */}
          {viewMode === 'week' && (
            <div className="grid grid-cols-7 gap-2">
              {weekDates.map((date, index) => {
                const isToday = formatDate(date) === formatDate(new Date());
                const dayTrainings = getTrainingsForDate(date);
                
                return (
                  <div
                    key={index}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      isToday 
                        ? 'bg-primary/10 border-primary' 
                        : 'bg-secondary border-border hover:bg-secondary/80'
                    }`}
                    onClick={() => setSelectedDate(date)}
                  >
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground mb-1">
                        {weekDays[index]}
                      </div>
                      <div className={`text-lg font-medium ${
                        isToday ? 'text-primary' : 'text-foreground'
                      }`}>
                        {date.getDate()}
                      </div>
                      {dayTrainings.length > 0 && (
                        <div className="mt-2">
                          <Badge variant="secondary" className="text-xs">
                            {dayTrainings.length} тренировок
                          </Badge>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Training List */}
        <div className="grid lg:grid-cols-2 gap-6">
          {filteredTrainings.map((training) => (
            <Card key={training.id} className="aiga-card p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold text-foreground mb-2">{training.title}</h3>
                  <p className="text-muted-foreground">{training.trainer}</p>
                </div>
                <Badge 
                  className={training.isBooked ? 'aiga-gradient text-white' : 'bg-secondary'}
                >
                  {training.isBooked ? 'Забронировано' : 'Доступно'}
                </Badge>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-muted-foreground">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>{new Date(training.date).toLocaleDateString('ru-RU', { 
                    weekday: 'long', 
                    day: 'numeric', 
                    month: 'long' 
                  })}</span>
                </div>
                
                <div className="flex items-center text-muted-foreground">
                  <Clock className="w-4 h-4 mr-2" />
                  <span>{training.time} ({training.duration} мин)</span>
                </div>
                
                <div className="flex items-center text-muted-foreground">
                  <MapPin className="w-4 h-4 mr-2" />
                  <span>{training.location}</span>
                </div>
                
                <div className="flex items-center text-muted-foreground">
                  <Users className="w-4 h-4 mr-2" />
                  <span>{training.currentParticipants}/{training.maxParticipants} участников</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-primary">{training.price.toLocaleString()} ₸</div>
                  <div className="text-sm text-muted-foreground">{training.level}</div>
                </div>
                
                <Button
                  className={training.isBooked ? 'bg-secondary text-foreground' : 'aiga-gradient text-white hover:opacity-90'}
                  disabled={training.isBooked || training.currentParticipants >= training.maxParticipants}
                  onClick={() => handleBooking(training)}
                >
                  {training.isBooked ? 'Забронировано' : 
                   training.currentParticipants >= training.maxParticipants ? 'Мест нет' : 'Записаться'}
                </Button>
              </div>

              {/* Progress bar for participants */}
              <div className="mt-4">
                <div className="flex justify-between text-sm text-muted-foreground mb-1">
                  <span>Заполненность</span>
                  <span>{Math.round((training.currentParticipants / training.maxParticipants) * 100)}%</span>
                </div>
                <div className="w-full bg-secondary rounded-full h-2">
                  <div 
                    className="aiga-progress-bar h-2 rounded-full" 
                    style={{ width: `${(training.currentParticipants / training.maxParticipants) * 100}%` }}
                  ></div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {filteredTrainings.length === 0 && (
          <Card className="aiga-card p-12 text-center">
            <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-bold text-foreground mb-2">Тренировок не найдено</h3>
            <p className="text-muted-foreground">
              Попробуйте изменить фильтры или выбрать другую дату
            </p>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Schedule;

