import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Star, Award, Calendar, MessageCircle } from 'lucide-react';
import trainer1 from '../assets/trainer_new_1.png';
import trainer2 from '../assets/trainer_new_2.png';
import trainer3 from '../assets/trainer_new_3.png';

const Trainers = () => {
  const trainers = [
    {
      id: 1,
      name: 'Алибек Нурланов',
      title: 'Главный тренер по BJJ',
      image: trainer1,
      achievements: ['Чемпион Азии 2022', 'Мастер спорта РК', '3x Чемпион Казахстана'],
      rating: 4.9,
      students: 150,
      specialization: ['Бразильское джиу-джитсу', 'Грэпплинг', 'Самооборона'],
      description: 'Опытный тренер с международным опытом. Специализируется на технической подготовке и развитии соревновательных навыков.'
    },
    {
      id: 2,
      name: 'Данияр Касымов',
      title: 'Тренер по грэпплингу',
      image: trainer2,
      achievements: ['Призер чемпионата мира', 'КМС по самбо', 'Тренер года 2023'],
      rating: 4.8,
      students: 95,
      specialization: ['Грэпплинг', 'Физическая подготовка', 'Детские группы'],
      description: 'Молодой и энергичный тренер, отлично работает с начинающими спортсменами и детскими группами.'
    },
    {
      id: 3,
      name: 'Айгерим Сейтова',
      title: 'Тренер женских групп',
      image: trainer3,
      achievements: ['Чемпионка Казахстана', 'Призер Кубка Азии', 'Лучший женский тренер'],
      rating: 5.0,
      students: 75,
      specialization: ['Женские группы', 'Самооборона', 'Фитнес-джиу-джитсу'],
      description: 'Единственная женщина-тренер в команде. Специализируется на женских группах и программах самообороны.'
    }
  ];

  return (
    <section id="trainers" className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Наши тренеры
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Команда профессиональных инструкторов с международным опытом и множеством наград. 
            Каждый тренер имеет свою специализацию и готов помочь вам достичь ваших целей.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {trainers.map((trainer) => (
            <Card key={trainer.id} className="aiga-card overflow-hidden">
              {/* Trainer Image */}
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={trainer.image} 
                  alt={trainer.name}
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute top-4 right-4 bg-primary/90 text-white px-3 py-1 rounded-full text-sm font-medium">
                  {trainer.belt}
                </div>
              </div>

              <div className="p-6">
                {/* Trainer Info */}
                <div className="mb-4">
                  <h3 className="text-xl font-bold text-foreground mb-1">{trainer.name}</h3>
                  <p className="text-primary font-medium mb-2">{trainer.title}</p>
                  <p className="text-sm text-muted-foreground leading-relaxed">{trainer.description}</p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-4 py-4 border-y border-border">
                  <div className="text-center">
                    <div className="text-lg font-bold text-primary">{trainer.experience}</div>
                    <div className="text-xs text-muted-foreground">Опыт</div>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center text-lg font-bold text-primary">
                      <Star className="w-4 h-4 mr-1 fill-current" />
                      {trainer.rating}
                    </div>
                    <div className="text-xs text-muted-foreground">Рейтинг</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-primary">{trainer.students}</div>
                    <div className="text-xs text-muted-foreground">Учеников</div>
                  </div>
                </div>

                {/* Achievements */}
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-foreground mb-2 flex items-center">
                    <Award className="w-4 h-4 mr-2 text-primary" />
                    Достижения
                  </h4>
                  <ul className="space-y-1">
                    {trainer.achievements.slice(0, 2).map((achievement, index) => (
                      <li key={index} className="text-xs text-muted-foreground flex items-center">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></div>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Specialization */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-foreground mb-2">Специализация</h4>
                  <div className="flex flex-wrap gap-2">
                    {trainer.specialization.map((spec, index) => (
                      <span 
                        key={index}
                        className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1 aiga-gradient text-white hover:opacity-90">
                    <Calendar className="w-4 h-4 mr-2" />
                    Записаться
                  </Button>
                  <Button size="sm" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                    <MessageCircle className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
            Посмотреть всех тренеров
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Trainers;

