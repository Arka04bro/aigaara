import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  User, 
  Calendar, 
  Trophy, 
  Target, 
  Clock, 
  Star, 
  TrendingUp, 
  Settings,
  LogOut,
  ChevronDown,
  Bell,
  CreditCard
} from 'lucide-react';

const UserProfile = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const upcomingTrainings = [
    {
      id: 1,
      title: 'Бразильское джиу-джитсу',
      trainer: 'Алибек Нурланов',
      date: '2025-07-22',
      time: '18:00',
      duration: '90 мин',
      location: 'Зал 1'
    },
    {
      id: 2,
      title: 'Грэпплинг',
      trainer: 'Данияр Касымов',
      date: '2025-07-24',
      time: '19:00',
      duration: '75 мин',
      location: 'Зал 2'
    }
  ];

  const recentAchievements = [
    {
      id: 1,
      title: 'Первая победа',
      description: 'Выиграли первый спарринг',
      date: '2025-07-15',
      points: 50
    },
    {
      id: 2,
      title: 'Регулярность',
      description: '10 тренировок подряд',
      date: '2025-07-10',
      points: 100
    }
  ];

  const trainingHistory = [
    {
      id: 1,
      date: '2025-07-20',
      program: 'BJJ Основы',
      trainer: 'Алибек Нурланов',
      duration: '90 мин',
      rating: 5
    },
    {
      id: 2,
      date: '2025-07-18',
      program: 'Грэпплинг',
      trainer: 'Данияр Касымов',
      duration: '75 мин',
      rating: 4
    }
  ];

  return (
    <div className="min-h-screen bg-background pt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="aiga-card p-8 mb-8">
          <div className="flex flex-col lg:flex-row items-start lg:items-center gap-6">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="w-12 h-12 text-primary" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">{user.name}</h1>
                <p className="text-muted-foreground mb-2">{user.email}</p>
                <Badge className="aiga-gradient text-white">{user.belt}</Badge>
              </div>
            </div>
            
            <div className="flex-1 lg:ml-8">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{user.trainings}</div>
                  <div className="text-sm text-muted-foreground">Тренировок</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{user.points}</div>
                  <div className="text-sm text-muted-foreground">Очков</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">3</div>
                  <div className="text-sm text-muted-foreground">Месяца</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">4.8</div>
                  <div className="text-sm text-muted-foreground">Рейтинг</div>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Настройки
              </Button>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Выйти
              </Button>
            </div>
          </div>
        </Card>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 mb-8 bg-card rounded-lg p-1">
          {[
            { id: 'overview', label: 'Обзор', icon: Target },
            { id: 'schedule', label: 'Расписание', icon: Calendar },
            { id: 'history', label: 'История', icon: Clock },
            { id: 'achievements', label: 'Достижения', icon: Trophy }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <tab.icon className="w-4 h-4 mr-2" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <Card className="aiga-card p-6">
                  <h3 className="text-xl font-bold text-foreground mb-4">Прогресс этого месяца</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Тренировки</span>
                        <span className="text-sm font-medium text-primary">11/16</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="aiga-progress-bar h-2 rounded-full" style={{ width: '68.75%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Цель по очкам</span>
                        <span className="text-sm font-medium text-primary">167/200</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="aiga-progress-bar h-2 rounded-full" style={{ width: '83.5%' }}></div>
                      </div>
                    </div>
                  </div>
                </Card>

                <Card className="aiga-card p-6">
                  <h3 className="text-xl font-bold text-foreground mb-4">Ближайшие тренировки</h3>
                  <div className="space-y-4">
                    {upcomingTrainings.map((training) => (
                      <div key={training.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                        <div>
                          <h4 className="font-medium text-foreground">{training.title}</h4>
                          <p className="text-sm text-muted-foreground">{training.trainer}</p>
                          <p className="text-sm text-muted-foreground">{training.date} в {training.time}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-primary">{training.duration}</p>
                          <p className="text-sm text-muted-foreground">{training.location}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            )}

            {activeTab === 'history' && (
              <Card className="aiga-card p-6">
                <h3 className="text-xl font-bold text-foreground mb-4">История тренировок</h3>
                <div className="space-y-4">
                  {trainingHistory.map((training) => (
                    <div key={training.id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                      <div>
                        <h4 className="font-medium text-foreground">{training.program}</h4>
                        <p className="text-sm text-muted-foreground">{training.trainer}</p>
                        <p className="text-sm text-muted-foreground">{training.date}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-primary">{training.duration}</p>
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < training.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {activeTab === 'achievements' && (
              <Card className="aiga-card p-6">
                <h3 className="text-xl font-bold text-foreground mb-4">Достижения</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {recentAchievements.map((achievement) => (
                    <div key={achievement.id} className="p-4 bg-secondary rounded-lg">
                      <div className="flex items-center mb-2">
                        <Trophy className="w-5 h-5 text-primary mr-2" />
                        <h4 className="font-medium text-foreground">{achievement.title}</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{achievement.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">{achievement.date}</span>
                        <span className="text-sm font-medium text-primary">+{achievement.points} очков</span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="aiga-card p-6">
              <h3 className="text-lg font-bold text-foreground mb-4">Быстрые действия</h3>
              <div className="space-y-3">
                <Button className="w-full aiga-gradient text-white hover:opacity-90">
                  <Calendar className="w-4 h-4 mr-2" />
                  Записаться на тренировку
                </Button>
                <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Продлить абонемент
                </Button>
                <Button variant="outline" className="w-full">
                  <Bell className="w-4 h-4 mr-2" />
                  Уведомления
                </Button>
              </div>
            </Card>

            <Card className="aiga-card p-6">
              <h3 className="text-lg font-bold text-foreground mb-4">Статистика</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Всего тренировок</span>
                  <span className="font-medium text-foreground">47</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Средняя оценка</span>
                  <span className="font-medium text-foreground">4.8</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Пропущено</span>
                  <span className="font-medium text-foreground">2</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Следующий пояс</span>
                  <span className="font-medium text-primary">Фиолетовый</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;

